nav element - Used ti creare a Navigation bar
.navbar - Display flex and justify-content: space-btw
.navbar-expand - Rearranges the menu items ( Nav ul: display flex)
.bg dark/light - Add background color of black or white
.navbar-dark/light - Changes the color of the menu text( black or white)
.navbar-brand - Navigation logo or branding
.navbar-nav - Add display flex to menu items, removes list styles and centers the menu items