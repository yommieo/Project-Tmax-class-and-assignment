Top part-Navigation(logo,menu and social media icons)
Hero section- Background image with text and button
Main section- display product
Footer section-display our policy and icon
CDN- content delivery 


assignment
display products
diplay 3 items on a row(do it just the way we added the about page)

question: how to dim or reduce image brightness without affecting the text