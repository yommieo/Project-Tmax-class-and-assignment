recreate screen shoot with navigation bar at the top and also make it responsive...i.e when u move the screen to a particular screensize it should be able to adjust




Assignment

Using the image above, recreate using bootstrap… Include a responsive navigation bar and make it responsive to any screen size

Deadline: 12th Dec 2022
Time: 7pm